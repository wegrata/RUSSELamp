/**
 */
package org.alfresco.filesys.auth.ftp;
